<?php
require_once "include/database-connection.php";

if (isset($_GET['id']) && isset($_GET['action'])) {
    $expense_id = intval($_GET['id']);
    $action = $_GET['action'];

    if ($action == 'approve') {
        $update_status = "UPDATE expenses SET statuts = 'Approuvé par Admin' WHERE id = $expense_id";
    } elseif ($action == 'reject') {
        $update_status = "UPDATE expenses SET statuts = 'Refusé' WHERE id = $expense_id";
    }

    mysqli_query($conn, $update_status);
    header("Location: demandeAdmin.php"); // Rediriger vers la page d'administration après mise à jour
    exit();
}
?>