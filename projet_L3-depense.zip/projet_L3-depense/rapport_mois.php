<?php 
    require_once "include/header.php";
?>

<!-- script to show modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>

<?php
       
       $firstDayErr = $lastDayErr = "";

       $firstDay= $lastDay = "";

        $item = $date = $price = $user = "";

        $i= 1;
        require_once "include/database-connection.php";
        if($_SERVER["REQUEST_METHOD"] == "POST"){
            
            // echo "clicked";

            if(empty($_REQUEST["premier_jour"])){
                $firstDayErr =" <p style='color:red'>* entrez une date </p>";
            } else {
                $firstDay = $_REQUEST["premier_jour"];
            } 
               
            if(  $_POST["jourHier"] == "0" ){
               $lastDayErr = " <p style='color:red'>* selectionnez une option </p>";

            } elseif ($_POST["jourHier"] == "1" ){
                $temp_lastDay = strtotime( $firstDay."-1 month");
                $lastDay= date( "d-m-Y", $temp_lastDay);

                
                $sql_command = "SELECT date , detail , montant_depen, email FROM expenses WHERE date   BETWEEN '$lastDay' AND '$firstDay' AND email = '$_SESSION[email]' ORDER BY date " ;
               
                $result = mysqli_query($conn , $sql_command);
                $rows = mysqli_num_rows($result);
                
                ?>
                
<div class='container '> 
    <h4 class='text-center pt-5 hide'>Rapport des dépenses mensuel </h4>
        <table class='table table-bordered table-hover border-primary mt-5 bg-light shadow hide'>
            <thead> 
                <tr>
                    <th> id </th>
                    <th> Date </th>
                    <th> Description </th>
                    <th> Prix en $</th>
                    <th> utilisateur</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    if( $rows > 0){
                    while($rows = mysqli_fetch_assoc($result)){
                    $date = $rows["date"]; 
                    $date = date( 'd-m-Y' , strtotime($date) );
                    $item =  $rows["detail"];
                    $price =  $rows["montant_depen"];
                    $user = $rows["email"];
                    echo "<tr> <th> $i   </th> <th>  $date  </th> <th>" .  ucwords($item) . " </th> <th>   $price</th> <th>   $user</th> </tr> ";
                    $i++;
              } 
                 echo "</tbody> </table> ";
                echo "<style> #form{ display:none } </style>";
                echo "<div class='text-center pt-4 pb-5'> <a href='rapport_mois.php' class='btn btn-primary btn-lg'> Voir plus </a> 
                <a href='pdf_gen.php?premier_jour={$firstDay}&jourHier={$lastDay}' class='btn btn-danger btn-lg text-white'> Afficher en PDF</a> </div>";

                } else {
                    $firstDay = date( 'd-m-Y' , strtotime("$firstDay") );
                    $lastDay = date( 'd-m-Y' , strtotime("$lastDay") );

                    echo "<script>
                    $(document).ready(function() {
                        $('#addMsg').text( 'aucun résultat trouvé entre $lastDay et $firstDay. '  );
                        $('#changeHrefForAdding').attr('href', 'ajout_depense.php');
                        $('#changeHrefForAdding').text('Ajouter des dépenses pour ce mois');
                        $('#showModal').modal('show');
                        $('.hide').hide();
                     });
                 </script>";
                }

            }  else {
                $temp_lastDay = strtotime( $firstDay."+1 month");
                $lastDay= date( "d-m-Y", $temp_lastDay);    
                 $sql_command = "SELECT date , detail , montant_depen, email FROM expenses WHERE date   BETWEEN '$firstDay' AND '$lastDay' AND email = '$_SESSION[email]' ORDER BY date " ;
                
                 $result = mysqli_query($conn , $sql_command);
                 $rows = mysqli_num_rows($result);
                

                 ?>

                <div class='container '> 
                    <h4 class='text-center pt-5 hide'> Rapport des dépenses mensuel </h4>
                        <table class='table table-bordered table-hover border-primary bg-light shadow mt-5 hide'>
                            <thead> 
                                <tr>
                                    <th> id </th>
                                    <th> Date </th>
                                    <th> Description </th>
                                    <th> Prix en $</th>
                                    <th>utilisateur </th>
                                </tr>
                            </thead>
                                <tbody>
                                <?php 
                 if( $rows > 0){
                   while( $rows = mysqli_fetch_assoc($result) ){
                   
                      $date = $rows["date"];
                      $date = date( 'd-m-Y' , strtotime($date) );
                      $item = $rows["detail"];
                      $price = $rows["montant_depen"]; 
                      $user = $rows["email"];

                         echo "<tr> <th> $i   </th> <th>  $date  </th> <th>   $item</th> <th>   $price</th>  <th>   $user</th> </tr> ";
                         $i++;
                        } 
                echo "</tbody> </table> ";
                echo "<style> #form{ display:none } </style>";
                echo "<div class='text-center pt-4 pb-5'> <a href='rapport_mois.php' class='btn btn-primary btn-lg'> Voir plus </a> 
                <a href='pdf_gen.php?premier_jour={$firstDay}&jourHier={$lastDay}' class='btn btn-danger btn-lg text-white'> Afficher en PDF </a> </div>";

                } else {
                    $firstDay = date( 'd-m-Y' , strtotime("$firstDay") );
                    $lastDay = date( 'd-m-Y' , strtotime("$lastDay") );
                    echo "<script>
                    $(document).ready(function() {
                        $('#addMsg').text( 'aucun résultat trouvé entre $firstDay et $lastDay. '  );
                        $('#changeHrefForAdding').attr('href', 'ajout_depense.php');
                        $('#changeHrefForAdding').text('Ajouter des dépenses pour ce mois');
                        $('#showModal').modal('show');
                        $('.hide').hide();
                     });
                 </script>";
                }
            }    
}

?>

<div class="container ">

               <div id="form" class="pt-5 form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5 shadow">
                                    <h4 class="text-center">Rapport des dépenses mensuel </h4>
                                <form method="POST" action=" <?php htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                            
                                <div class="form-group">
                                    <label >Selectionnez le premier jour du mois:</label>
                                    <input type="date" class="form-control" value="<?php echo $firstDay; ?>" name="premier_jour" >  
                                    <?php echo  $firstDayErr; ?>                   
                                </div>

                                <div class="form-group">
                                    <select class="form-control" name = "jourHier">
                                        <option value="0"> Afficher rapport d'aprçs ou d'avant </option>
                                       <option value="1"> Rapport d'avant la date selectionnée</option>
                                        <option value="2"> Rapport d'après la date selectionnée</option>     
                                    </select> 
                                   <?php echo $lastDayErr; ?>               

                                </div>

                                <div class="form-group">
                                    <input type="submit" value="Afficher rapport" class="btn login-form__btn submit w-10 " name="submit_expense" >
                                </div>
                                <div class="form-group">
                                    <a href="index.php" class="btn login-form__btn submit w-70">Retour</a>
                                </div> 
                                  </form>
                            </div>
                        </div>
                    </div>
</div>
</div>



<?php 
    require_once "include/footer.php";
?>