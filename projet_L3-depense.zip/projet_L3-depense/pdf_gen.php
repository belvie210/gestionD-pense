<?php 
session_start();
require_once 'include/database-connection.php';
require 'fpdf/fpdf.php';

$thirdDate = $forthDate = "";
$firstDate = $_GET["premier_jour"];
$lastDate = $_GET["jourHier"];

if ($lastDate > $firstDate) {
    // Dates déjà dans l'ordre
} else {
    // Échange des dates
    $thirdDate = $firstDate;
    $forthDate = $lastDate;
    $firstDate = $forthDate;
    $lastDate = $thirdDate;
}

// Récupération des dépenses
$sql_query = "SELECT date, detail, montant_depen FROM expenses WHERE date BETWEEN '$firstDate' AND '$lastDate' AND email = '$_SESSION[email]' ORDER BY date";
$result = mysqli_query($conn, $sql_query);
$row = mysqli_num_rows($result);

// Formatage des dates
$firstDateFormatted = date('d-m-Y', strtotime($firstDate));
$lastDateFormatted = date('d-m-Y', strtotime($lastDate));

$name = ucwords($_SESSION["nom_user"]);
$current_date = date('d-m-Y'); // Formater la date actuelle

ob_start();
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 25);
$i = 1;
$pdf->Cell(190, 70, "Systeme de gestion des depenses", '', '0', 'C'); 
$pdf->Ln(60);
$pdf->SetFont('Arial', '', 18);
$pdf->Cell(40, 10, "Noms : ", '', '0', 'C');
$pdf->Cell(24, 10, "$name", '', '0', 'C');
$pdf->Ln();

$pdf->Cell(40, 10, "Date actuelle : ", '', '0', 'C');
$pdf->Cell(45, 10, "$current_date", '', '0', 'C'); // Utiliser la date actuelle formatée
$pdf->Ln(40);

$pdf->Cell(190, 10, "Date depense :", '', '0', 'C');
$pdf->Ln();
$pdf->Cell(190, 10, "$firstDateFormatted et $lastDateFormatted", '', '0', 'C'); // Dates formatées
$pdf->Ln(50);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(12, 10, "No.", '1', '0', 'C');
$pdf->Cell(30, 10, "Date", '1', '0', 'C');
$pdf->Cell(125, 10, "Description", '1', '0', 'C');
$pdf->Cell(25, 10, "Montant en $", '1', '0', 'C');
$pdf->Ln(10);   

$total_montant = 0; // Initialiser le total

while ($row = mysqli_fetch_assoc($result)) {     
    $pdf->Cell(12, 10, $i, '1', '0', 'C'); 
    $pdf->Cell(30, 10, date('d-m-Y', strtotime($row['date'])), '1', '0', 'C'); // Formater la date des dépenses
    $pdf->Cell(125, 10, $row['detail'], '1', '0', 'C');
    $pdf->Cell(25, 10, $row['montant_depen'], '1', '0', 'C');     
    $pdf->Ln(10);   
    $total_montant += $row['montant_depen']; // Ajouter au total
    $i++;   
}

// Afficher le montant total
$pdf->Cell(12, 10, '', '0', '0', 'C'); 
$pdf->Cell(30, 10, '', '0', '0', 'C'); 
$pdf->Cell(125, 10, "Total des depenses :", '1', '0', 'C');
$pdf->Cell(25, 10, "$total_montant", '1', '0', 'C');    

$pdf->Output();
ob_end_flush();
?>