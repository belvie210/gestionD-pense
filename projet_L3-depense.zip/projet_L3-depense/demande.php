<?php

require_once "include/header.php";
require_once "include/database-connection.php";

$email = $_SESSION["email"];
$requests = [];

// Vérification des demandes approuvées et rejetées
$request_query = "SELECT * FROM demandes WHERE email = ? AND (admin_approb = 'Approve' OR admin_approb = 'Rejete' OR directeur_approb = 'Rejete')";
$stmt = mysqli_prepare($conn, $request_query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while ($row = mysqli_fetch_assoc($result)) {
    $requests[] = $row;
}

// Gestion de l'enregistrement de la nouvelle demande
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST["expense_date"];
    $item = trim(htmlspecialchars($_POST["item"]));
    $price = floatval($_POST["expense_price"]);

    if (empty($date) || empty($item) || empty($price)) {
        $error = "Tous les champs sont requis.";
    } else {
        $expense_query = "INSERT INTO demandes (email, detail, montant_depen, date, admin_approb, directeur_approb) VALUES (?, ?, ?, ?, 'En attente', 'En attente')";
        $stmt = mysqli_prepare($conn, $expense_query);
        mysqli_stmt_bind_param($stmt, "ssds", $email, $item, $price, $date);
        
        if (mysqli_stmt_execute($stmt)) {
            echo "<div class='alert alert-success'>Demande de sortie de fonds soumise avec succès !</div>";
        } else {
            $error = "Erreur lors de la soumission de la demande : " . mysqli_error($conn);
        }
    }
}
?>

<div class="container">
    <h4 class="text-center">Demandes d'enregistrements</h4>
    
    <?php if (!empty($error)) echo "<p style='color:red'>$error</p>"; ?>
    
    <h5>Soumettre une nouvelle demande</h5>
    <form method="POST" action="">
        <div class="form-group">
            <label>Date de dépense :</label>
            <input type="date" class="form-control" name="expense_date" required>
        </div>

        <div class="form-group">
            <label>Description :</label>
            <input type="text" class="form-control" name="item" required>
        </div>

        <div class="form-group">
            <label>Montant :</label>
            <input type="number" class="form-control" name="expense_price" required min="0.01" step="0.01">
        </div>

        <div class="form-group">
            <input type="submit" value="Soumettre la demande" class="btn btn-primary">
        </div>
    </form>

    <h5 class="mt-4">Mes Demandes</h5>
    <table class="table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Montant</th>
                <th>Statut</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($requests)): ?>
                <tr>
                    <td colspan="4" class="text-center">Aucune demande soumise.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($requests as $request): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($request['date']); ?></td>
                        <td><?php echo htmlspecialchars($request['detail']); ?></td>
                        <td><?php echo htmlspecialchars($request['montant_depen']); ?></td>
                        <td>
                            <?php 
                                if ($request['admin_approb'] === 'Rejete' || $request['directeur_approb'] === 'Rejete') {
                                    echo "Rejeté";
                                } else {
                                    echo "Approuvé";
                                }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once "include/footer.php"; ?>