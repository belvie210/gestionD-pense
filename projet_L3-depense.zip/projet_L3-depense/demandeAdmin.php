<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "include/header.php";
require_once "include/database-connection.php";

if ($_SESSION["id_categ"] != 1) { // ID pour admin
    header("Location: index.php");
    exit;
}

$requests = [];
$request_query = "SELECT * FROM demandes WHERE admin_approb = 'En attente' OR directeur_approb = 'En attente'";
$result = mysqli_query($conn, $request_query);
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

while ($row = mysqli_fetch_assoc($result)) {
    $requests[] = $row;
}

// Gestion des approbations et des rejets
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['request_id']);
    $action = isset($_POST['approve']) ? 'Approve' : (isset($_POST['rejeter']) ? 'Rejete' : null);

    if ($action) {
        $update_query = "UPDATE demandes SET admin_approb = ? WHERE id = ?";
        if ($stmt = mysqli_prepare($conn, $update_query)) {
            mysqli_stmt_bind_param($stmt, "si", $action, $id);
            if (mysqli_stmt_execute($stmt)) {
                // Message de succès
                echo "<div class='alert alert-success'>Demande mise à jour avec succès !</div>";
            } else {
                // Message d'erreur
                echo "<div class='alert alert-danger'>Erreur lors de la mise à jour de la demande : " . mysqli_error($conn) . "</div>";
            }
            mysqli_stmt_close($stmt);
        } else {
            die("Preparation failed: " . mysqli_error($conn));
        }
        // Redirection après un petit délai pour voir le message
        header("refresh:2;url=demandeAdmin.php");
        exit();
    } else {
        die("Action non reconnue.");
    }
}
?>

<div class="container">
    <h4 class="text-center">Approbation des demandes (Admin)</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Email</th>
                <th>Description</th>
                <th>Montant</th>
                <th>Date</th>
                <th>Statut Directeur</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($requests)): ?>
                <tr>
                    <td colspan="6" class="text-center">Aucune demande en attente.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($requests as $request): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($request['email']); ?></td>
                        <td><?php echo htmlspecialchars($request['detail']); ?></td>
                        <td><?php echo htmlspecialchars($request['montant_depen']); ?></td>
                        <td><?php echo htmlspecialchars($request['date']); ?></td>
                        <td><?php echo htmlspecialchars($request['directeur_approb']); ?></td>
                        <td>
                            <form method="POST" action="">
                                <input type="hidden" name="request_id" value="<?php echo htmlspecialchars($request['id']); ?>">
                                <input type="submit" name="approve" value="Approuver" class="btn btn-success">
                                <input type="submit" name="rejeter" value="Rejeter" class="btn btn-danger">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once "include/footer.php"; ?>