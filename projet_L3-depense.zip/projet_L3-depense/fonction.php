<?php 
    function getCategories() {
        require "include/database-connection.php";

                  // Récupérer les catégories depuis la base de données
                    $sql = "SELECT * FROM categories";
                    $result = $conn->query($sql);

                        $categories = [];
                        if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                            $categories[] = ['id' => $row['id'], 'name' => $row['nom']];
                                }
                            }
                          // Fermer la connexion
                                $conn->close();

                                return $categories;
                        }

    function getCategorie() {
        require "include/database-connection.php";

                  // Récupérer les catégories depuis la base de données
                    $sql = "SELECT * FROM categories";
                    $result = $conn->query($sql);

                        $categories = [];
                        if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                            $categories[] = ['id' => $row['id'], 'name' => $row['id_user']];
                                }
                            }
                          // Fermer la connexion
                                $conn->close();

                                return $categories;
                        }

                        function getUserByEmailAndCategories($email, $categorie_id) {
                            require "include/database-connection.php";
                                      // Récupérer l'utilisateur depuis la base de données
                            $sql = "SELECT u.*, c.nom AS nom_categorie 
                            FROM users u
                            JOIN categories c ON u.categorie_id = c.id
                            WHERE u.email = ? AND u.categorie_id = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("si", $email, $categorie_id);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $user = null;
                            if ($result->num_rows > 0) {
                            $user = $result->fetch_assoc();
                            $stmt->close();
                            $conn->close();
                                                                                        
                            return $user;
                                    }
                        }
?> 