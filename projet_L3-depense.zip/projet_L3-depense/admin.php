<?php
    require_once "include/header.php";
    if ($_SESSION["id_categ"] != 1) { // Assuming 1 is the ID for admin
    header("Location: index.php"); // Redirect if not admin
    exit;
}
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>


<?php
require "include/database-connection.php";
 $email = $_SESSION["email"];
        $user= $id=$name= $catego= $date_creat= "";
        $sql_command = "SELECT
          u.id AS id_user,
            u.nom_user AS nom_user,
              c.nom AS grade,
                c.date_creat AS date_creat,
                    u.email
                    FROM
                      users u
                      LEFT JOIN
                        categories c ON u.id_categ = c.id
                        GROUP BY
                          u.id, u.nom_user, c.nom, c.date_creat, u.email
                          ORDER BY
                            u.email;";
        $result = mysqli_query($conn ,$sql_command ) ;
            $row = mysqli_num_rows($result);
?>
 

<div class="container bg-light shadow mt-5">

<h4 class='text-center pt-5 hide'>Tous les personnels de l'entreprise </h4>

<table class=" table table-bordered table-hover border-primary">
  <thead>
    <tr>
     <th scope="col">No.</th>
      <th scope="col">Nom</th>
      <th scope="col">Categorie</th>
      <th scope="col">Email</th>
      <th scope="col">Date création</th>
    </tr>
  </thead>
  <tbody>
<?php

  if( $row > 0){
    while( $row = mysqli_fetch_assoc($result)){  
            $id = $row["id_user"];
            $nom = $row["nom_user"];
            $catego = $row["grade"];
            $email =  $row["email"];
            $date_creat = $row["date_creat"];
            $edit_icon = "<span ><i class='fa fa-edit'></i></span> ";
            $edit = " <a href='update_user.php?nom_user={$nom}&id_grade={$catego}&email={$email}' class='btn-sm btn-primary float-right'> $edit_icon </a> ";
            $bin = " <a href='user_suppr.php?id={$id}' id='bin' class='btn-sm btn-primary float-right ml-2'> <span ><i class='fa fa-trash '></i></span> </a> ";
           echo " <tr> <th> {$id}. </th> <th> {$nom} </th> <th> {$catego} </th> <th> {$email} </th> <th> {$date_creat} </th> <th>{$bin} {$edit}  </th>
                  "; 
    }



}else {
  echo "<script>
  $(document).ready(function() {
      $('#addMsg').text( 'Aucune dépense!');
      $('#changeHrefForAdding').attr('href','ajout_depense.php');
      $('#changeHrefToShowReport').text('Me rappeler plus tard');
      $('#changeHrefForAdding').text('Ajouter dépenses');
      $('#showModal').modal('show');
    });
    </script>";
}

?>
  
  </tbody>
</table>

</div>

 <div class="form-group">
    <a href="AjoutBalance.php" class="btn login-form__btn submit w-70">Ajout Budget</a>
 </div>
 <div class="form-group">
    <a href="ajoutGrade.php" class="btn login-form__btn submit w-70">Ajout Grâdes</a>
  </div>
   <div class="form-group">
      <a href="demandeAdmin.php" class="btn login-form__btn submit w-70">Afficher démande</a>
  </div>
  <div class="form-group">
    <a href="gerer_demAdmin.php" class="btn login-form__btn submit w-70">Gerer demande</a>
 </div>
<?php 
require "include/database-connection.php";


        $i = 1;
        $email = $_SESSION["email"];
        $date = $item = $price =$user= $id=$name= "";
      
        
        $sql_command = "SELECT u.email, u.nom_user, DATE(e.date) AS date_depense, e.detail, e.id, 
        COALESCE(SUM(e.montant_depen),0) AS total_depense FROM users u LEFT JOIN expenses e
         ON u.email=e.email GROUP BY u.email = e.email, u.nom_user, DATE(e.date),e.detail,e.id ORDER BY u.email,date_depense";
        $result = mysqli_query($conn ,$sql_command ) ;
            $row = mysqli_num_rows($result);
  
  
?>




<div class="container bg-light shadow mt-5">

<h4 class='text-center pt-5 hide'>Tous les enregistrements et  les enregistreurs </h4>

<table class=" table table-bordered table-hover border-primary">
  <thead>
    <tr>
     <th scope="col">No.</th>
      <th scope="col">Nom</th>
      <th scope="col">Date d'enreistrement</th>
      <th scope="col">Description</th>
      <th scope="col">Montant en $</th>
      <th scope="col">utilisateur</th>
      
    </tr>
  </thead>
  <tbody>
<?php

  if( $row > 0){
    while( $row = mysqli_fetch_assoc($result)){  
            $id = $row["id"];
            $name = $row["nom_user"];
            $date = $row["date_depense"];
            $datef = date( 'd-m-Y' , strtotime($date) );
            $item = $row["detail"];
            $price = $row["total_depense"];
            $user =  $row["email"];
            $edit_icon = "<span ><i class='fa fa-edit'></i></span> ";
            $edit = " <a href='update_depense.php?id={$id}&nom_user={$name}&detail={$item}&montant_depen={$price}&date={$date}&email={$user}' class='btn-sm btn-primary float-right'> $edit_icon </a> ";
            $bin = " <a href='supp_depense.php?id={$id}' id='bin' class='btn-sm btn-primary float-right ml-2'> <span ><i class='fa fa-trash '></i></span> </a> ";
            echo " <tr> <th> {$i}. </th> <th> {$name} </th> <th> {$datef} </th> <th> {$item} </th> <th> {$price} </th> <th> {$user} {$bin} {$edit}  </th>
                  "; 
        $i++;
    }



}else {
  echo "<script>
  $(document).ready(function() {
      $('#addMsg').text( 'Aucune dépense!');
      $('#changeHrefForAdding').attr('href','dg.php');
      $('#changeHrefToShowReport').text('me rappeler plus tard');
      $('#changeHrefForAdding').text('Ajouter dépenses');
      $('#showModal').modal('show');
    });
    </script>";
}

?>
  
  </tbody>
</table>

</div>

<div class="form-group">
    <a href="acces_admin.php" class="btn login-form__btn submit w-70">Retour</a>
</div>

<?php
    require_once "include/footer.php";
?>