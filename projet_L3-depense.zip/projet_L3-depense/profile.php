

<?php 
ob_start();
require_once "include/header.php"; 
   require "include/database-connection.php";

?>

<div class="container">

  <div class="row">
      <div class="col-4">

      </div>

      <div class="col-4 col-12-md">
      <div class="card shadow">
    <img src="resorce/images/users/1.jpg" class="img-thumbnail"  height="4px">
    <div class="card-body">

      <h1 class=" text-center"> <?php  echo ucwords($_SESSION["nom_user"]); ?> </h1>
      <p class="card-text mt-5">Noms : <?php echo ucwords($_SESSION["nom_user"]); ?></p>
      <p class="card-text">Email: <?php echo $_SESSION["email"]; ?></p>
      <p class="card-text"> Date de naissance : <?php echo date( 'd-m-Y' , strtotime($_SESSION["date_naiss"]) ); ?> </p>
      <p class="card-text">Grâde: <?php echo ucwords($_SESSION["id_categ"]); ?></p>
      <div class="text-center"> 
      <a class='btn  btn-primary text-white' href="update-profile.php" >Modifier Profil </a><br><br>
      <a class='btn btn-primary text-white' href="change-pass.php" >Changer mot de passe</a><br><br>
      <a class='btn btn-primary text-white' href="index.php" >Fermer</a>
      
      
      </div>

    </div>
  </div>
    </div>

  </div>

</div>

<script>

</script>

<?php 
    require_once "include/footer.php";
?>