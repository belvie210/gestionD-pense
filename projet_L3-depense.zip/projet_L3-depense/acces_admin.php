<?php
ob_start(); // Start output buffering

// Include the header
require_once "include/header.php";

// Initialize variables
$emailErr = $passErr = $loginErr = $categoErr = "";
$email = $pass = $catego = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include the database connection
    require "include/database-connection.php";

    // Validate email
    if (empty($_POST["email"]) || !filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $emailErr = "<p style='color:red'>* Email est requis</p>";
    } else {
        $email = trim(htmlspecialchars($_POST["email"]));
    }

    // Validate password
    if (empty($_POST["mot_de_passe"])) {
        $passErr = "<p style='color:red'>* Mot de passe est requis</p>";
    } else {
        $pass = trim(htmlspecialchars($_POST["mot_de_passe"]));
    }

    // Validate category
    if (empty($_POST["id_grade"])) {
        $categoErr = "<p style='color:red'>* Grade est requis</p>";
    } else {
        $catego = trim(htmlspecialchars($_POST["id_grade"]));
    }

    // Authenticate user only if all inputs are valid
    if (!empty($email) && !empty($pass) && !empty($catego)) {
        $sql_command = "SELECT * FROM users WHERE email=? AND mot_de_passe=? AND id_categ=?";
        $stmt = mysqli_prepare($conn, $sql_command);
        mysqli_stmt_bind_param($stmt, "ssi", $email, $pass, $catego);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            // session_start(); // Start the session

            $_SESSION["email"] = $user["email"];
            $_SESSION["nom_user"] = $user["nom_user"];
            $_SESSION["date_naiss"] = $user["date_naiss"];
            $_SESSION["id_categ"] = $user["id_categ"];

            if ($user['id_categ'] == 1) { // 1 = admin
                header("Location: admin.php?login-success"); // Redirect to admin page
                exit;
            } elseif ($user['id_categ'] == 4) { // 4 = directeur
                header("Location: dg.php?login-success"); // Redirect to director page
                exit;
            } else {
                header("Location: authentification.php?login-échec");
            }
        } else {
           
             echo "<script>
                    $(document).ready(function() {
                        $('#addMsg').text( 'identifications incorects !');
                        $('#changeHrefToShowReport').text('Ok, merci !');
                        $('#changeHrefForAdding').text('vérifiez bien vos informations !');
                        $('#showModal').modal('show');
                        });
                        </script>";
        }
    }
}

// Page content
ob_end_flush(); // Flush the output buffer
?>

<div class="login-form-bg h-100">
    <div class="container h-100">
        <div class="row justify-content-center h-100">
            <div class="col-xl-6">
                <?php echo $loginErr; ?>
                <div class="form-input-content">
                    <div class="card login-form mb-0">
                        <div class="card-body pt-5 shadow">
                            <h4 class="text-center">Place réservée pour Admin et Directeur</h4>

                            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                                <div class="form-group">
                                    <label>Votre adresse email :</label>
                                    <input type="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" name="email" placeholder="Entrez votre adresse email">  
                                    <?php echo $emailErr; ?>       
                                </div>

                                <div class="form-group">
                                    <label>Mot de passe :</label>
                                    <input type="mot_de_passe" class="form-control" name="mot_de_passe" placeholder="Entrez votre mot de passe">
                                    <?php echo $passErr; ?>
                                </div>

                                <div class="form-group">
                                    <label for="id_grade">Rôle ou grade :</label>
                                    <select name="id_grade" id="id_grade" class="form-control">
                                        <option value="">Sélectionnez votre rôle</option>
                                        <?php
                                        require "fonction.php";
                                        $categories = getCategories();
                                        foreach ($categories as $category) {
                                            $selected = ($category['id'] == $catego) ? 'selected' : '';
                                            echo '<option value="' . htmlspecialchars($category['id']) . '" ' . $selected . '>' . htmlspecialchars($category['name']) . '</option>';
                                        }
                                        ?> 
                                    </select>
                                    <?php echo $categoErr; ?>
                                </div>

                                <div class="form-group">
                                    <input type="submit" class="btn login-form__btn submit w-100" name="signin">
                                </div>
                                 <div class="form-group">
                                    <a href="index.php" class="btn login-form__btn submit w-70">Retour</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once "include/footer.php"; ?>