<?php
require_once "include/header.php";
require "include/database-connection.php";
if ($_SESSION["id_categ"] != 1) { // Assuming 1 is the ID for admin
    header("Location: index.php"); // Redirect if not admin
    exit;
}
if (isset($_GET['id'])) {
    $expense_id = $_GET['id'];
   
    // Récupérer les données existantes
    $sql = "SELECT * FROM expenses WHERE id = $expense_id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    if (!$row) {
        echo "Dépense non trouvée.";
        exit;
    }

    // Variables pour le formulaire
    $date = $row['date'];
    $item = $row['detail'];
    $price = $row['montant_depen'];

    // Traitement du formulaire
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $date = $_POST['date_depense'];
        $item = $_POST['detail'];
        $price = $_POST['montant_depen'];

        // Mettre à jour dans la base de données
        $sql = "UPDATE expenses SET date='$date', detail='$item', montant_depen='$price' WHERE id=$expense_id";
        if ($conn->query($sql) === TRUE) {
            header("Location: demandeAdmin.php"); // Redirection après mise à jour
            exit;
        } else {
            echo "Erreur : " . $conn->error;
        }
    }
}
?>

<div class="container">
    <h4 class="text-center">Mettre à jour la dépense</h4>
    <form method="POST" action="">
        <div class="form-group">
            <label>Date de dépense :</label>
            <input type="date" class="form-control" name="date_depense" value="<?php echo $date; ?>" required>
        </div>
        <div class="form-group">
            <label>Description :</label>
            <input type="text" class="form-control" name="detail" value="<?php echo $item; ?>" required>
        </div>
        <div class="form-group">
            <label>Montant :</label>
            <input type="number" class="form-control" name="montant_depen" value="<?php echo $price; ?>" required>
        </div>
        <div class="form-group">
            <input type="submit" value="Mettre à jour" class="btn btn-primary">
        </div>
    </form>
</div>

<?php
require_once "include/footer.php";
?>