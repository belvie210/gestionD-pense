<?php
require_once "include/header.php";
require_once "include/database-connection.php";

// Assurez-vous que la session est démarrée

if (!isset($_SESSION["email"])) {
    header("Location: authentification.php");
    exit();
}

$email = $_SESSION["email"];

// Vérification des demandes approuvées
$request_query = "SELECT montant_depen, COUNT(*) as approbations FROM demandes WHERE email = ? AND admin_approb = 'Approve' AND directeur_approb = 'Approve'";
$stmt = mysqli_prepare($conn, $request_query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result === false || mysqli_num_rows($result) === 0) {
    echo "<p style='color:red'>Accès refusé : Vous devez avoir une demande approuvée pour accéder à cette page.</p>";
    exit();
}

// Récupérer le montant approuvé et le nombre d'approbations
$row = mysqli_fetch_assoc($result);
$approvedAmount = $row['montant_depen'];
$approbationsCount = $row['approbations'];

// Gestion de la soumission de la dépense
$date = $item = $price = $categorie_id = "";
$error = "";
$expenseRecorded = isset($_SESSION['expense_recorded']) && $_SESSION['expense_recorded']; // Vérifiez l'état depuis la session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $categorie_id = $_POST["categorie_id"];

    if (empty($_POST["date_depense"]) || empty($_POST["detail"])) {
        $error = "Tous les champs sont requis.";
    } else {
        $date = $_POST["date_depense"];
        $item = trim($_POST["detail"]);
        $price = floatval($_POST["montant_depen"]);

        if ($price <= 0) {
            $error = "Le montant doit être supérieur à zéro.";
        } elseif ($price !== floatval($approvedAmount)) {
            $error = "Le montant doit être exactement de " . htmlspecialchars($approvedAmount) . ".";
        } else {
            $expense_query = "INSERT INTO expenses (email, detail, montant_depen, date, id_grade) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $expense_query);
            mysqli_stmt_bind_param($stmt, "ssdsd", $email, $item, $price, $date, $categorie_id);

            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['expense_recorded'] = true; // Mettre à jour la variable de session
                mysqli_stmt_close($stmt);
            } else {
                $error = "Erreur lors de l'enregistrement de la dépense : " . mysqli_error($conn);
            }
        }
    }
}
?>

<div class="container">
    <h4 class="text-center">Enregistrement de la dépense</h4>
    <form method="POST" action="">
        <div class="form-group">
            <label>Date de dépense :</label>
            <input type="date" class="form-control" name="date_depense" required>
        </div>

        <div class="form-group">
            <label>Description :</label>
            <input type="text" class="form-control" name="detail" required>
        </div>

        <?php if (!$expenseRecorded): // Afficher le champ montant seulement si aucune dépense n'est enregistrée ?>
            <div class="form-group">
                <label>Montant :</label>
                <input type="number" class="form-control" name="montant_depen" required min="0.01" step="0.01" value="<?php echo htmlspecialchars($approvedAmount); ?>" readonly>
            </div>
        <?php else: // Message à afficher après l'enregistrement ?>
            <p style='color:green'>Dépense enregistrée avec succès ! Vous pouvez faire une nouvelle demande d'enregistrement.</p>
        <?php endif; ?>

        <div class="form-group">
            <label for="categorie_id">Rôle ou grade :</label>
            <select name="categorie_id" id="categorie_id" class="form-control" required>
                <option value="">Sélectionner votre rôle</option>
                <?php
                require "fonction.php";
                $catego = getCategories();
                foreach ($catego as $categotie) {
                    echo '<option value="' . htmlspecialchars($categotie['id']) . '">' . htmlspecialchars($categotie['name']) . '</option>';
                }
                ?> 
            </select>
        </div>

        <div class="form-group">
            <input type="submit" value="Enregistrer la dépense" class="btn login-form__btn submit w-10">
        </div>
        <?php if (!empty($error)) echo "<p style='color:red'>$error</p>"; ?>
    </form>
</div>

<?php require_once "include/footer.php"; ?>