<?php 
session_start();
require_once 'include/database-connection.php';
require 'fpdf/fpdf.php';

$date = $_GET["date"];
$sql_query = "SELECT date, detail, montant_depen FROM expenses WHERE date = '$date' AND email = '$_SESSION[email]' ";
$result = mysqli_query($conn, $sql_query);
$row = mysqli_num_rows($result);

$date = date('d-m-Y', strtotime($date));
$name = ucwords($_SESSION["nom_user"]);
$current_date = date('d-m-Y', strtotime('now'));

ob_start();
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 25);
$i = 1;
$pdf->Cell(190, 70, "Systeme de gestion des depenses", '', '0', 'C'); 
$pdf->Ln(60);
$pdf->SetFont('Arial', '', 18);
$pdf->Cell(40, 10, "Noms : ", '', '0', 'C');
$pdf->Cell(24, 10, "$name", '', '0', 'C');
$pdf->Ln();

$pdf->Cell(40, 10, "Date actuelle : ", '', '0', 'C');
$pdf->Cell(45, 10, "$current_date", '', '0', 'C');
$pdf->Ln(40);

$pdf->Cell(190, 10, " Date depense:", '', '0', 'C');
$pdf->Ln();
$pdf->Cell(190, 10, "$date", '', '0', 'C');
$pdf->Ln(50);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(12, 10, "No.", '1', '0', 'C');
$pdf->Cell(30, 10, "Date", '1', '0', 'C');
$pdf->Cell(125, 10, "Decription", '1', '0', 'C');
$pdf->Cell(25, 10, "Montant en $", '1', '0', 'C'); 
$pdf->Ln(10);   

$total_montant = 0; // Initialiser le total

while ($row = mysqli_fetch_assoc($result)) {     
    $pdf->Cell(12, 10, $i, '1', '0', 'C'); 
    $pdf->Cell(30, 10, $row['date'], '1', '0', 'C'); 
    $pdf->Cell(125, 10, $row['detail'], '1', '0', 'C');
    $pdf->Cell(25, 10, $row['montant_depen'], '1', '0', 'C');    
    $pdf->Ln(10);
    $total_montant += $row['montant_depen']; // Ajouter au total
    $i++;   
}

// Afficher le montant total
$pdf->Cell(12, 10, '', '0', '0', 'C'); 
$pdf->Cell(30, 10, '', '0', '0', 'C'); 
$pdf->Cell(125, 10, "Total des depenses :", '1', '0', 'C');
$pdf->Cell(25, 10, "$total_montant", '1', '0', 'C');    

$pdf->Output();
ob_end_flush();
?>