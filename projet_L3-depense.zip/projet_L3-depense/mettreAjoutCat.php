<?php
ob_start(); // Start output buffering

// Include the header
require_once "include/header.php";
if ($_SESSION["id_categ"] != 1) { // Assuming 1 is the ID for admin
    header("Location: index.php"); // Redirect if not admin
    exit;
}
// Initialize variables
$categoryID = $categoryName = $categoryDescription = $categoryUpdatedMsg = $categoryErrorMsg = "";

// Check if a category ID is provided for editing
if (isset($_GET['id'])) {
    $categoryID = intval($_GET['id']); // Récupérer l'ID de la catégorie
    // Include the database connection
    require_once "include/database-connection.php";

    // Fetch the category details
    $fetch_category = "SELECT * FROM categories WHERE id=?";
    $stmt = mysqli_prepare($conn, $fetch_category);
    mysqli_stmt_bind_param($stmt, "i", $categoryID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($result) {
        $category = mysqli_fetch_assoc($result);
        if ($category) {
            // Check if category exists
            $categoryName = $category['nom'];
            $categoryDescription = $category['description'];
        } else {
            $categoryErrorMsg = "<p style='color:red'>Grâde non trouvée.</p>";
        }
    } else {
        $categoryErrorMsg = "<p style='color:red'>Erreur lors de la récupération de la grâde : " . mysqli_error($conn) . "</p>";
    }
}

// Handle update form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_category'])) {
    // Include the database connection
    require_once "include/database-connection.php";

    // Validate category name
    if (empty($_POST["category_name"])) {
        $categoryErrorMsg .= "<p style='color:red'>* Nom de grâde requis</p>";
    } else {
        $categoryName = trim($_POST["category_name"]);
    }

    // Validate category description
    if (empty($_POST["category_description"])) {
        $categoryErrorMsg .= "<p style='color:red'>* Description de grâde requise</p>";
    } else {
        $categoryDescription = trim($_POST["category_description"]);
    }

    // Process the request if inputs are valid
    if (empty($categoryErrorMsg)) {
        // Update the category in the database using prepared statements
        $update_category = "UPDATE categories SET nom=?, description=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $update_category);
        mysqli_stmt_bind_param($stmt, "ssi", $categoryName, $categoryDescription, $categoryID);
        
        if (mysqli_stmt_execute($stmt)) {
            $categoryUpdatedMsg = "<div class='alert alert-success'>Grâde mise à jour avec succès !</div>";
        } else {
            $categoryErrorMsg = "<p style='color:red'>Erreur lors de la mise à jour de la grâde : " . mysqli_error($conn) . "</p>";
        }
    }
}

// Page content
ob_end_flush(); // Flush the output buffer
?>

<div class="container">
    <h4>Mettre à Jour une grâde</h4>
    <?php echo $categoryUpdatedMsg; ?>
    <?php echo $categoryErrorMsg; ?>
    
    <div class="form-input-content m-5">
        <div class="card login-form mb-0">
            <div class="card-body pt-5 shadow">
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'] . "?id=" . $categoryID); ?>">
                    <div class="form-group">
                        <label>Categorie :</label>
                        <select name="categorie_id" id="categorie_id" class="form-control" required onchange="updateCategory(this.value)">
                            <option value="">Sélectionner une catégorie</option>
                            <?php
                            require "fonction.php";
                            $catego = getCategories();
                            foreach ($catego as $categotie) {
                                echo '<option value="' . $categotie['id'] . '"' . ($categotie['id'] == $categoryID ? ' selected' : '') . '>' . htmlspecialchars($categotie['name']) . '</option>';
                            }
                            ?> 
                        </select>
                    </div>

                    <!-- Only show these fields if a category is selected -->
                    <?php if ($categoryID): ?>
                        <div class="form-group">
                            <label>Nom de la catégorie :</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($categoryName); ?>" name="category_name" required placeholder="Entrez le nom de la catégorie">
                        </div>

                        <div class="form-group">
                            <label>Description de la catégorie :</label>
                            <textarea class="form-control" name="category_description" rows="3" required placeholder="Entrez une description de la catégorie"><?php echo htmlspecialchars($categoryDescription); ?></textarea>
                        </div>

                        <div class="form-group">
                            <input type="submit" value="Mettre à Jour Catégorie" class="btn login-form__btn submit w-10" name="update_category">
                            <a href="ajoutGrade.php" class="btn login-form__btn submit w-10">Fermer</a>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function updateCategory(categoryId) {
    if (categoryId) {
        // Redirige vers la même page avec l'ID de la catégorie sélectionnée
        window.location.href = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=" + categoryId;
    } else {
        // Cache les champs si aucune catégorie n'est sélectionnée
        document.querySelector('input[name="category_name"]').value = '';
        document.querySelector('textarea[name="category_description"]').value = '';
    }
}
</script>

<?php require_once "include/footer.php"; ?>