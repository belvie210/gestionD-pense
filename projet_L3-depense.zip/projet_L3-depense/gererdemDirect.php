<?php
require_once "include/header.php";
require_once "include/database-connection.php";

// Vérification de l'authentification
if (!isset($_SESSION["email"])) {
    header("Location: authentification.php");
    exit();
}

$email = $_SESSION["email"];

// Vérification du rôle (directeur)
$user_role_query = "SELECT id_categ FROM users WHERE email = ?";
$stmt = mysqli_prepare($conn, $user_role_query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user_role = mysqli_fetch_assoc($result)['id_categ'];

// Vérification des droits d'accès
if ($user_role !== 4) { // 4 pour directeur
    echo "<p style='color:red'>Accès refusé : Vous n'avez pas les droits nécessaires.</p>";
    exit();
}

// Gestion de la suppression d'une demande
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $delete_query = "DELETE FROM demandes WHERE id = ?";
    $delete_stmt = mysqli_prepare($conn, $delete_query);
    mysqli_stmt_bind_param($delete_stmt, "i", $id);
    mysqli_stmt_execute($delete_stmt);
    mysqli_stmt_close($delete_stmt);
    echo "<div class='alert alert-success'>Demande supprimée avec succès !</div>";
}

// Gestion de la modification d'une demande
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $montant_depen = floatval($_POST['montant_depen']);
    
    $update_query = "UPDATE demandes SET montant_depen = ? WHERE id = ?";
    $update_stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($update_stmt, "di", $montant_depen, $id);
    mysqli_stmt_execute($update_stmt);
    mysqli_stmt_close($update_stmt);
    echo "<div class='alert alert-success'>Demande modifiée avec succès !</div>";
}

// Récupérer les demandes
$request_query = "SELECT id, montant_depen FROM demandes";
$stmt = mysqli_prepare($conn, $request_query);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<div class="container">
    <h4 class="text-center">Gestion des demandes - Directeur</h4>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Montant de la demande</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['montant_depen']); ?></td>
                    <td>
                        <a href="javascript:void(0);" onclick="document.getElementById('updateForm<?php echo $row['id']; ?>').style.display='block'">Modifier</a> |
                        <a href="?action=delete&id=<?php echo $row['id']; ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette demande ?');">Supprimer</a>
                    </td>
                </tr>
                <tr id="updateForm<?php echo $row['id']; ?>" style="display:none;">
                    <td colspan="3">
                        <form method="POST" action="">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <div class="form-group">
                                <label>Montant :</label>
                                <input type="number" class="form-control" name="montant_depen" required min="0.01" step="0.01" value="<?php echo htmlspecialchars($row['montant_depen']); ?>">
                            </div>
                            <input type="submit" name="update" value="Mettre à jour" class="btn btn-primary">
                            <button type="button" class="btn btn-secondary" onclick="document.getElementById('updateForm<?php echo $row['id']; ?>').style.display='none'">Annuler</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    
</div>
<div class="form-group">
    <a href="dg.php" class="btn login-form__btn submit w-70">Retour</a>
 </div>
<?php require_once "include/footer.php"; ?>