<?php
ob_start(); // Start output buffering

// Include the header
require_once "include/header.php";
if ($_SESSION["id_categ"] != 1) { // Assuming 1 is the ID for admin
    header("Location: index.php"); // Redirect if not admin
    exit;
}
// Initialize variables for adding categories
$categoryName = $categoryDescription = $userId = $categoryAddedMsg = $categoryErrorMsg = "";

// Include the database connection
require_once "include/database-connection.php";

// Handle category form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_category'])) {
    // Validate category name
    if (empty($_POST["category_name"])) {
        $categoryErrorMsg = "<p style='color:red'>* Nom de catégorie requis</p>";
    } else {
        $categoryName = trim($_POST["category_name"]);
    }

    // Validate category description
    if (empty($_POST["category_description"])) {
        $categoryErrorMsg .= "<p style='color:red'>* Description de catégorie requise</p>";
    } else {
        $categoryDescription = trim($_POST["category_description"]);
    }

    // Validate user ID
    if (empty($_POST["user_id"]) || !is_numeric($_POST["user_id"])) {
        $categoryErrorMsg .= "<p style='color:red'>* ID utilisateur valide requis</p>";
    } else {
        $userId = intval(trim($_POST["user_id"]));
    }

    // Process the request if inputs are valid
    if (empty($categoryErrorMsg)) {
        // Escape values to prevent SQL injection
        $categoryName = mysqli_real_escape_string($conn, $categoryName);
        $categoryDescription = mysqli_real_escape_string($conn, $categoryDescription);
        $userId = mysqli_real_escape_string($conn, $userId);

        // Insert the new category into the database
        $add_category = "INSERT INTO categories (nom, description, user_id) VALUES ('$categoryName', '$categoryDescription', '$userId')";
        if (mysqli_query($conn, $add_category)) {
            $categoryAddedMsg = "<div class='alert alert-success'>Catégorie ajoutée avec succès !</div>";
            // Reset the inputs
            $categoryName = "";
            $categoryDescription = "";
            $userId = "";
        } else {
            $categoryErrorMsg = "<p style='color:red'>Erreur lors de l'ajout de la catégorie.</p>";
        }
    }
}

// Page content
ob_end_flush(); // Flush the output buffer
?>

<div class="container">
    <h4>Ajouter une Catégorie</h4>
    <?php echo $categoryAddedMsg; ?>
    <?php echo $categoryErrorMsg; ?>
    
    <div class="form-input-content m-5">
        <div class="card login-form mb-0">
            <div class="card-body pt-5 shadow">
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                    <div class="form-group">
                        <label>Nom de la grâde :</label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($categoryName); ?>" name="category_name" required placeholder="Entrez le nom de la catégorie">
                    </div>

                    <div class="form-group">
                        <label>Description de la grâde :</label>
                        <textarea class="form-control" name="category_description" rows="3" required placeholder="Entrez une description de la catégorie"><?php echo htmlspecialchars($categoryDescription); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>ID Utilisateur :</label>
                        <input type="number" class="form-control" value="<?php echo htmlspecialchars($userId); ?>" name="user_id" required placeholder="Entrez l'ID utilisateur">
                    </div>

                    <div class="form-group">
                        <label for="categorie_id">Grâde existant :</label>
                        <select name="categorie_id" id="categorie_id" class="form-control">
                            <option value="">Sélectionner votre rôle</option>
                            <?php
                            require "fonction.php";
                            $catego = getCategories();
                            foreach ($catego as $categotie) {
                                echo '<option value="' . $categotie['id'] . '">' . htmlspecialchars($categotie['name']) . '</option>';
                            }
                            ?> 
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="submit" value="Ajouter Catégorie" class="btn login-form__btn submit w-10" name="submit_category">
                        <a href="mettreAjoutCat.php" class="btn login-form__btn submit w-10">Mettre à jour</a>
                        <a href="suppCat.php" class="btn login-form__btn submit w-10">Supprimer</a>
                        <a href="admin.php" class="btn login-form__btn submit w-10">Fermer</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once "include/footer.php"; ?>