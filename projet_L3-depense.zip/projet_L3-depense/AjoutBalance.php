<?php
ob_start(); // Start output buffering

// Include the header
require_once "include/header.php";

// Initialize variables
$addBalanceMsg = $errorMsg = "";
$categorie_id = $amountToAdd = "";

// Check if the user is an admin
if ($_SESSION["id_categ"] != 1) { // Assuming 1 is the ID for admin
    header("Location: index.php"); // Redirect if not admin
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include the database connection
    require_once "include/database-connection.php";

    // Validate amount
    if (empty($_POST["montant_ajouter"]) || !is_numeric($_POST["montant_ajouter"]) || $_POST["montant_ajouter"] <= 0) {
        $errorMsg = "<p style='color:red'>* Montant valide est requis</p>";
    } else {
        $amountToAdd = floatval(trim($_POST["montant_ajouter"]));
    }

    // Validate category
    if (empty($_POST["id_grade"])) {
        $errorMsg .= "<p style='color:red'>* Grâde est requise</p>";
    } else {
        $categorie_id = intval(trim($_POST["id_grade"]));
    }

    // Process the request if all inputs are valid
    if (empty($errorMsg)) {
        // Update the balance
        $updateBalance = "UPDATE categories SET balance = balance + '$amountToAdd' WHERE id='$categorie_id'";
        if (mysqli_query($conn, $updateBalance)) {
            $addBalanceMsg = "<div class='alert alert-success'>Montant ajouté avec succès à la balance !</div>";
        } else {
            $errorMsg = "<p style='color:red'>Erreur lors de l'ajout du montant.</p>";
        }
    }
}

// Page content
ob_end_flush(); // Flush the output buffer
?>

<div class="container">
    <?php echo $addBalanceMsg; ?>
    <?php echo $errorMsg; ?>
    
    <div class="form-input-content m-5">
        <div class="card login-form mb-0">
            <div class="card-body pt-5 shadow">
                <h4 class="text-center">Ajouter Montant à la Balance</h4>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                    <div class="form-group">
                        <label for="amount_to_add">Montant à ajouter :</label>
                        <input type="number" class="form-control" name="montant_ajouter" value="<?php echo $amountToAdd; ?>" placeholder="Entrez le montant" required>
                    </div>

                    <div class="form-group">
                        <label for="id_grade">Catégorie :</label>
                        <select name="id_grade" id="id_grade" class="form-control" required>
                            <option value="">Sélectionnez une catégorie</option>
                            <?php
                            require "fonction.php";
                            $categories = getCategories();
                            foreach ($categories as $category) {
                                echo '<option value="' . $category['id'] . '">' . $category['name'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="submit" value="Ajouter Montant" class="btn login-form__btn submit w-10">
                       <a href="miseAjour_balance.php" class="btn login-form__btn submit w-10">Metre à jour </a>
                       <a href="supp_balance.php" class="btn login-form__btn submit w-10">Supprimer</a>
                      <a href="admin.php" class="btn login-form__btn submit w-10">Fermer</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once "include/footer.php"; ?>