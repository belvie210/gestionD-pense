<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="resorce/css/style.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
</head>

<body class="h-100">
    <!-- <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div> -->

    <!-- Login PHP script -->
<?php

$emailErr = $passErr = $loginErr = $categoErr= $nom="";

$email = $pass = $catego= $nomErr= "";

if ( $_SERVER["REQUEST_METHOD"] == "POST" ){

// database connnection

require "include/database-connection.php";
if ( empty($_POST["nom"] )) {

$nomErr = " <p style='color:red'>* Noms sont requissent </p>";

}else {

$nom = trim(htmlspecialchars($_POST["nom"]));

}
if ( empty($_POST["email"] || !filter_var($email, FILTER_VALIDATE_EMAIL))) {

$emailErr = " <p style='color:red'>* Email est requis </p>";

}else{

$email = trim(htmlspecialchars($_POST["email"]));

}

if ( empty($_POST["password"] )) {

$passErr = " <p style='color:red'>* Mot de passe requis </p>";

}else {

$pass = trim(htmlspecialchars($_POST["password"]));

}

if ( empty($_POST["categorie_id"] )) {

$categoErr = " <p style='color:red'>* grâde est requise</p>";

}else {

$catego = trim(htmlspecialchars($_POST["categorie_id"]));

}

if (!empty($email) && !empty($pass) && !empty($catego) ){

$sql_command = " SELECT * FROM users WHERE nom_user='$nom'AND email='$email' AND mot_de_passe='$pass' AND id_categ='$catego' ";

$result =mysqli_query($conn , $sql_command);

$row = mysqli_num_rows($result);

if($row > 0){

while( $row = mysqli_fetch_assoc($result) ){

session_start();

$_SESSION["email"] = $row["email"];

$_SESSION["nom_user"] = $row["nom_user"];

$_SESSION["date_naiss"] = $row["date_naiss"];

$_SESSION["id_categ"] = $row["id_categ"];

header("Location: index.php?login-success");

}

}else {

$loginErr = " <script> alert('Vos informations sont incorectes !') </script>";


}

}

}

?>

    <!-- End PHP script -->
   <div class="login-form-bg h-100">
    <div class="container h-100">
        <div class="row justify-content-center h-100">
            <div class="col-xl-6">
                <?php echo $loginErr; ?>
                <div class="form-input-content">
                    <div class="card login-form mb-0">
                        <div class="card-body pt-5 shadow">
                          
                                <h4 class="text-center">Système de gestion des dépenses D'espérance médical </h4>
                                <h4 class="text-center">Page de connection pour tous les personnels</h4>

                            <form method="POST" action=" <?php htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                         
                            <div class="form-group">
                                <label >Noms :</label>
                                <input type="text" class="form-control" value="<?php echo $nom; ?>"  name="nom" placeholder="Entrez votre noms">  
                                <?php echo  $nomErr; ?>       
                            </div>
                            <div class="form-group">
                                <label >Email :</label>
                                <input type="email" class="form-control" value="<?php echo $email; ?>"  name="email" placeholder="Entrez votre adresse mail">  
                                <?php echo  $emailErr; ?>       
                            </div>
                            <div class="form-group">
                                <label >Mot de passe :</label>
                                <input type="password" class="form-control" name="password" placeholder="Entrez votre mot de passe">
                                <?php echo  $passErr; ?>
                            </div>
                            <div class="form-group">
                                <label  for="categorie_id">Grâde :</label>
                                <select name="categorie_id" id="categorie_id" class="form-control">
                                <option value="">Selectionner votre grâde</option>
                                <?php
                                 require "fonction.php";
                                    $catego = getCategories();
                                        foreach ($catego as $categotie) {
                                            $selected = ($categotie['id'] == $catego) ? 'selected' : '';
                                        echo '<option value="' . $categotie['id'] . '" ' . $selected . '>' . $categotie['name'] . '</option>';
                                        }
                                            ?> 
                                </select>
                                
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn login-form__btn submit w-100 " name="signin" >
                            </div>

                              </form>
                            <p class="mt-5 login-form__footer">vous n'avez pas un compte ? <a href="signup.php" class="text-primary">S'inscrire</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<!--**********************************
    Scripts
***********************************-->
<script src="resorce/plugins/common/common.min.js"></script>
<script src="resorce/js/custom.min.js"></script>
<script src="resorce/js/settings.js"></script>
<script src="resorce/js/gleek.js"></script>
<script src="resorce/js/styleSwitcher.js"></script>