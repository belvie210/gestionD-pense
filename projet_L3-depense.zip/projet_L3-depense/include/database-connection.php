<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "projet_l3_depense";

$conn = mysqli_connect($dbhost , $dbuser , $dbpass , $dbname);

if(!isset($conn)){
    echo die("Database connection failed");
} 
mysqli_set_charset($conn, "utf8");

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
?>