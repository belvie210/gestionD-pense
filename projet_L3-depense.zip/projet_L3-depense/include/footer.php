
</div>
            <!-- #/ container -->
</div>
      
 
<div class="footer hide">
            <div class="copyright">
                <p>Copyright &copy; developpé par  <a href="#">Belvie BOKULU</a> 2024</p>
            </div>
        </div>
        
    </div>
   
    <script src="./resorce/plugins/common/common.min.js"></script>
    <script src="./resorce/js/custom.min.js"></script>
    <script src="./resorce/js/settings.js"></script>
    <script src="./resorce/js/gleek.js"></script>
    <script src="./resorce/js/styleSwitcher.js"></script>

</body>

</html>