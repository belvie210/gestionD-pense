<?php
    require_once "include/header.php";
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>

   <?php

        $date = $item = $price= "";
        $dateErr = $itemErr = $priceErr = "";
         $email = $_SESSION["email"];

        
         $id= $_GET["id"];
         $date = $_GET["date"];
         $item = $_GET["detail"];
         $price= $_GET["montant_depen"];

            if($_SERVER["REQUEST_METHOD"] == "POST" ){
                
               require_once "include/database-connection.php";

                if( empty($_POST["date_depense"]) ){
                    $dateErr = "<P style='color:red'>* Entrez la date </p>";
                    $date = "";
               }else {
                   $date = trim($_POST["date_depense"]);
               }

               if( empty($_POST["detail"]) ){
                $itemErr = "<P style='color:red'>* Ajouter une description</p>";
                $item ="";
              }else {
               $item = trim($_POST["detail"]);
               $item = ucwords($item);
              }

              if( empty($_POST["montant_depen"]) ){
                $priceErr = "<P style='color:red'>* Entrez un montant </p>";
                $price = "";
              }else {
               $price = trim($_POST["montant_depen"]);
              }

              if ( !empty($date) && !empty($item) && !empty($price) ){
                   
               $sql = "UPDATE expenses SET date = '$date' , detail='$item' , montant_depen='$price' WHERE id='$id' ";
               $result = mysqli_query($conn , $sql);

              

                  echo "<script>
                  $(document).ready(function() {
                      $('#addMsg').text( 'Dépense mise à jour  de $price $ avec succes!');
                      $('#changeHrefToShowReport').hide();
                      $('#modalHead').hide();

                      $('#changeHrefForAdding').attr('href','Affichange_depense.php');
                      $('#changeHrefForAdding').text('Ok, merci !');
                      $('#showModal').modal('show');
                    });
                    </script>";
             
       }
               

   }

   ?>

          <div class="container m-5">
              
          <div class="container row">
          <div class="col align-self-center">
               <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5">
                                    <h4 class="text-center">Modification depense </h4>

                                <form method="POST" action=" <?php htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                            
                                <div class="form-group">
                                    <label >Date :</label>
                                    <input type="date" class="form-control" value="<?php echo $date; ?>"  name="date_depense" placeholder="entrez la date de dépense" required>
                                    <?php echo $dateErr; ?>                     
                                </div>

                                <div class="form-group">
                                    <label >Description :</label>
                                    <input type="text" class="form-control" value="<?php echo $item; ?>" name="detail" placeholder="Ajouetr une Description" required>
                                    <?php echo $itemErr; ?>        
                                </div>

                                <div class="form-group">
                                    <label >Montant:</label>
                                    <input type="number" class="form-control " value="<?php echo $price; ?>"  name="montant_depen" placeholder="entrez un montant" required>
                                    <?php echo $priceErr; ?>        
                                </div>

                                <div class="form-group">
                                    <input type="submit" value="Modifier" class="btn login-form__btn submit w-10 " name="submit_expense" >
                                </div>
  
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                </div>


</div>

<?php
    require_once "include/footer.php";
?>