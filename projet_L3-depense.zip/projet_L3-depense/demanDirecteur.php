<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "include/header.php";
require_once "include/database-connection.php";

if ($_SESSION["id_categ"] != 4) { // ID pour directeur
    header("Location: index.php");
    exit;
}

$requests = [];
$request_query = "SELECT * FROM demandes WHERE (admin_approb = 'Approve' AND directeur_approb = 'En attente') OR (admin_approb = 'Rejete' AND directeur_approb = 'En attente')";
$result = mysqli_query($conn, $request_query);
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

while ($row = mysqli_fetch_assoc($result)) {
    $requests[] = $row;
}

// Gestion des approbations et des rejets
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['request_id']);
    $action = isset($_POST['approve']) ? 'Approve' : (isset($_POST['rejeter']) ? 'Rejete' : null);

    if ($action) {
        $update_query = "UPDATE demandes SET directeur_approb = ? WHERE id = ?";
        if ($stmt = mysqli_prepare($conn, $update_query)) {
            mysqli_stmt_bind_param($stmt, "si", $action, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        } else {
            die("Preparation failed: " . mysqli_error($conn));
        }
        header("Location: demanDirecteur.php");
        exit();
    } else {
        die("Action non reconnue.");
    }
}
?>

<div class="container">
    <h4 class="text-center">Approbation des demandes (Directeur)</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Email</th>
                <th>Description</th>
                <th>Montant</th>
                <th>Date</th>
                <th>Statut Admin</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($requests)): ?>
                <tr>
                    <td colspan="6" class="text-center">Aucune demande en attente.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($requests as $request): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($request['email']); ?></td>
                        <td><?php echo htmlspecialchars($request['detail']); ?></td>
                        <td><?php echo htmlspecialchars($request['montant_depen']); ?></td>
                        <td><?php echo htmlspecialchars($request['date']); ?></td>
                        <td><?php echo htmlspecialchars($request['admin_approb']); ?></td>
                        <td>
                            <form method="POST" action="">
                                <input type="hidden" name="request_id" value="<?php echo htmlspecialchars($request['id']); ?>">
                                <input type="submit" name="approve" value="Approuver" class="btn btn-success">
                                <input type="submit" name="rejeter" value="Rejeter" class="btn btn-danger">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once "include/footer.php"; ?>