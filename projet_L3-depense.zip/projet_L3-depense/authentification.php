<?php
require_once "include/header.php";
?>

<div class="container">
    <h4 class="text-center">Accès Non Autorisé</h4>
    <p class="text-center" style="color:red">Vous n'avez pas l'autorisation d'accéder à cette page.</p>
</div>
 <div class="form-group">
    <a href="index.php" class="btn login-form__btn submit w-70">Retour</a>
</div>

<?php require_once "include/footer.php"; ?>