<?php
ob_start(); // Start output buffering

// Include the header
require_once "include/header.php";

// Initialize variables
$updateBalanceMsg = $errorMsg = "";
$categorie_id = $amountToUpdate = "";

// Check if the user is an admin
if ($_SESSION["id_categ"] != 1) { // Assuming 1 is the ID for admin
    header("Location: index.php"); // Redirect if not admin
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include the database connection
    require_once "include/database-connection.php";

    // Validate amount
    if (empty($_POST["montant_update"]) || !is_numeric($_POST["montant_update"]) || $_POST["montant_update"] < 0) {
        $errorMsg = "<p style='color:red'>* Montant valide est requis</p>";
    } else {
        $amountToUpdate = floatval(trim($_POST["montant_update"]));
    }

    // Validate category
    if (empty($_POST["id_grade"])) {
        $errorMsg .= "<p style='color:red'>* Catégorie est requise</p>";
    } else {
        $categorie_id = intval(trim($_POST["id_grade"]));
    }

    // Process the request if all inputs are valid
    if (empty($errorMsg)) {
        // Update the balance
        $updateBalance = "UPDATE categories SET balance = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $updateBalance);
        mysqli_stmt_bind_param($stmt, "di", $amountToUpdate, $categorie_id);
        
        if (mysqli_stmt_execute($stmt)) {
            $updateBalanceMsg = "<div class='alert alert-success'>Montant mis à jour avec succès !</div>";
        } else {
            $errorMsg = "<p style='color:red'>Erreur lors de la mise à jour du montant.</p>";
        }
    }
}

// Get the existing balance if a category is selected
if (!empty($_GET["id_grade"])) {
    require_once "include/database-connection.php";
    $categorie_id = intval(trim($_GET["id_grade"]));
    $query = "SELECT balance FROM categories WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $categorie_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $amountToUpdate);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
}

// Page content
ob_end_flush(); // Flush the output buffer
?>

<div class="container">
    <?php echo $updateBalanceMsg; ?>
    <?php echo $errorMsg; ?>
    
    <div class="form-input-content m-5">
        <div class="card login-form mb-0">
            <div class="card-body pt-5 shadow">
                <h4 class="text-center">Mettre à Jour le Montant</h4>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                    <div class="form-group">
                        <label for="amount_to_update">Montant à mettre à jour :</label>
                        <input type="number" class="form-control" name="montant_update" value="<?php echo htmlspecialchars($amountToUpdate); ?>" placeholder="Entrez le montant" required>
                    </div>

                    <div class="form-group">
                        <label for="id_grade">Catégorie :</label>
                        <select name="id_grade" id="id_grade" class="form-control" required onchange="updateAmount(this.value)">
                            <option value="">Sélectionnez une catégorie</option>
                            <?php
                            require "fonction.php";
                            $categories = getCategories();
                            foreach ($categories as $category) {
                                echo '<option value="' . $category['id'] . '" ' . ($category['id'] == $categorie_id ? 'selected' : '') . '>' . $category['name'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="submit" value="Mettre à Jour" class="btn login-form__btn submit w-10">
                        <a href="AjoutBalance.php" class="btn login-form__btn submit w-10">Retour</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function updateAmount(categoryId) {
    if (categoryId) {
        window.location.href = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id_grade=" + categoryId;
    }
}
</script>

<?php require_once "include/footer.php"; ?>